# TryHackMe - Day 1
Completed first room.