# Project Idea
Build a simple phishing detector.