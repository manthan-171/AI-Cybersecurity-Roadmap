# Basic Linux Commands
- ls
- pwd
- cd