# SQL Notes

- SELECT * FROM users;