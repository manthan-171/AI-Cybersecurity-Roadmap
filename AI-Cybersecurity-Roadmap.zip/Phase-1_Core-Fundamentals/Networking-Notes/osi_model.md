# OSI Model Notes

7 Layers: Physical to Application